package com.devshiv.ytchannel.model

data class BannersModel(
    var VideoRef: String = "",
)